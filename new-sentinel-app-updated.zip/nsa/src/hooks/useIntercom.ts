import { useEffect, useState } from 'react';
import { useScript } from 'usehooks-ts';
// Updated import path - Growthbook removed, using stub implementation
import useRemoteConfig from './remote-config/useRemoteConfig';

export const useIntercom = (token: string | null) => {
    const intercom_script = 'https://static.deriv.com/scripts/intercom/v1.0.2.js';
    const { data } = useRemoteConfig(true);
    const { cs_chat_intercom } = data;
    const scriptStatus = useScript(cs_chat_intercom ? intercom_script : null);

    useEffect(() => {
        if (!cs_chat_intercom || scriptStatus !== 'ready' || !window?.DerivInterCom) return;

        let intervalId: NodeJS.Timeout;

        const initIntercom = () => {
            window.DerivInterCom.initialize({
                hideLauncher: true,
                token,
            });

            intervalId = setInterval(() => {
                if (window?.Intercom) {
                    clearInterval(intervalId);
                }
            }, 500);
        };

        initIntercom();

        return () => {
            clearInterval(intervalId);
        };
    }, [cs_chat_intercom, scriptStatus, token]);
};

export const useIsIntercomAvailable = () => {
    const [is_ready, setIsReady] = useState(false);

    useEffect(() => {
        const TIMEOUT_DURATION = 5000;
        const startTime = Date.now();

        const checkIntercom = setInterval(() => {
            if (typeof window.Intercom === 'function') {
                setIsReady(true);
                clearInterval(checkIntercom);
            } else if (Date.now() - startTime >= TIMEOUT_DURATION) {
                clearInterval(checkIntercom);
            }
        }, 100);

        return () => clearInterval(checkIntercom);
    }, []);

    return is_ready;
};

export default useIntercom;
